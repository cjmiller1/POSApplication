package posbackend;

public class Burger {
    private final Double burgerPrice = 6.99;

    public Double getBurgerPrice() {
        return burgerPrice;
    }
}
