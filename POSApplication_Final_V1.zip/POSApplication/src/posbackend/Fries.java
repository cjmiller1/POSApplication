package posbackend;

public class Fries {
    private final Double friesPrice = 2.00;

    public Double getFriesPrice() {
        return friesPrice;
    }
    
    
}
